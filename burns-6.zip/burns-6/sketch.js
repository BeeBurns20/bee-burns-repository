var verticalPosition = [12, 245, 129, 33, 111, 37, 152, 274, 116, 19];

function setup() {
  createCanvas(600, 600);
  print(`verticalPosition Length: ${verticalPosition.length}`);
}

function draw() {
  background(0, 0, 102);

  for (var i = 0; i < verticalPosition.length; i++) {
    fill(255,255,51);
  	ellipse(30+60*i, verticalPosition[i], 5, 5);

    if (verticalPosition[i] <=10) {
      verticalPosition[i] += random(0, 10);
    } 
    else if (verticalPosition[i] >=300){
      verticalPosition[i] += random(0, -10);
    }
    else if (verticalPosition[i] > 10 && verticalPosition[i] < 300){
      verticalPosition[i] += random(-10, 10);
    }
  }

    fill(255,255,255);
    noStroke();
    ellipse(300, 300, 145, 185); 
    fill(255);
    triangle(230, 320, 280, 320, 255, 450);
    triangle(260, 380, 340, 380, 300, 480);
    triangle(320, 320, 370, 320, 345, 450);
    stroke(0);
    strokeWeight(2);
    circle(275,250,50);
    circle(325,250,50);
    let x1 = map(mouseX,0,width,270,280);
    let y1 = map(mouseY,0,height,240,255);
    let x2 = map(mouseX,0,width,320,330);
    let y2 = map(mouseY,0,height,240,255);
    fill(0);
    ellipse(x1,y1,20);
    ellipse(x2,y2,20);
    fill(0);
    ellipse(300, 300, 15, 20);  
}