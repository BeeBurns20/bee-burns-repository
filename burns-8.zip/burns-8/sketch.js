let backgroundImg, butterfly;
let posX = 300;
let posY = 200;

function preload() {
  backgroundImg = loadImage('/burns-8/assets/backgroundImage.jpg');
  butterfly = loadImage('/burns-8/assets/butterfly.png');
}

function setup() {
  createCanvas(712, 400);
}

function draw() {
  background(backgroundImg);
  fill(0,76,153);
  stroke(102,204,0);
  strokeWeight(4);
  textSize(70);
  textFont('Impact')
  text("I'm A Butterfly!", 150, 50, 430, 150);
  textSize(20);
  noStroke();
  text("I will follow your mouse.", 260, 120, 430, 150);
  
    posX += (mouseX - posX) * 0.04;
    posY += (mouseY - posY) * 0.04; 

  image(butterfly, posX, posY);

}
