let xPositions = [120,490,260];
let yPositions = [110,200,220];
let scaleSize = [1,2.5,5];
let rotateAmount = [3,67,35];

function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES);
  rotationAmount();
}

function draw() {
  background(204,229,255);
  fill(0, 204, 0);
  rect(0, 275, 600, 325);
  for (let i = 0; i < 3; i++) {
    fill(255, 255, 255);
    push();
    translate(xPositions[i], yPositions[i]);
    scale(scaleSize[i]);
    rect(-2, 0, 4, 200);
    rotate(rotateAmount[i]);
    drawBlades(0, 0);
    pop();
  }
}

function drawBlades(x, y) {
  fill(255, 255, 255);
  push();
  rotate(55);
  ellipse(0, 25, 9, 50);
  pop();
  push();
  rotate(180);
  ellipse(0, 25, 9, 50);
  pop();
  push();
  rotate(305);
  ellipse(0, 25, 9, 50);
  pop();
  ellipse(x, y, 9, 9);
}

function rotationAmount() {
  for (let i = 0; i < rotateAmount.length; i++) {
    print("Rotation Amount: " + rotateAmount[i]);
  }
}